<template>
	<router-view />
</template>

<script setup></script>

<style>
* {
	padding: 0;
	margin: 0;
	box-sizing: border-box;
	list-style: none;
}
#app {
	font-family: Avenir, Helvetica, Arial, sans-serif;

	-webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	/* text-align: center; */
	color: #2c3e50;
}
</style>
