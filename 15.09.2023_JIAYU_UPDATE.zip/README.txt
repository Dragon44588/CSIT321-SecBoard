-
-
-
Please use
	npm install
in both frontend and backend, before you run 'npm run serve' and 'nodemon start server.js'